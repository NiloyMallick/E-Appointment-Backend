from django.contrib import admin

from contactform.models import *

admin.site.register(ContactFormData)
